package pl.reniferek.servertp;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public final class ServerTeleport extends JavaPlugin implements Listener {

    private final Set<UUID> inside = new HashSet<>();

    @Override
    public void onEnable() {
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("ServerTeleport wlaczony!");
    }

    @EventHandler
    public void onMove(PlayerMoveEvent event) {
        if (event.getTo() == null) return;

        Location loc = event.getTo();

        boolean inRegion =
                loc.getBlockX() >= -4 && loc.getBlockX() <= 4 &&
                loc.getBlockY() >= 68 && loc.getBlockY() <= 77 &&
                loc.getBlockZ() == 9;

        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();

        if (inRegion) {
            if (inside.add(uuid)) {
                player.performCommand("server LifeStealSMPspawn");
            }
        } else {
            inside.remove(uuid);
        }
    }

    @Override
    public void onDisable() {
        inside.clear();
    }
}
